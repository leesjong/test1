package com.dress.server.dto;

import lombok.Data;

@Data
public class Comment {
    private String message;
    private String createDate;
    private String uId;
    private int urPk;
    private int uPk;
}
