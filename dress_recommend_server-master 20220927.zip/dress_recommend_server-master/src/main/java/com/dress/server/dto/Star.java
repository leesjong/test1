package com.dress.server.dto;

import lombok.Data;

@Data
public class Star {
    private int sPk;
    private int rPk;
    private int uPk;
}
