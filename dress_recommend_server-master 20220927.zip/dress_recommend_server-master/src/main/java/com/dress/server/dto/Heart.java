package com.dress.server.dto;

import lombok.Data;

@Data
public class Heart {
    private int cnt;
    private int rPk;
    private int hPk;
    private int uPk;

}
