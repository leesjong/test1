package com.dress.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DressServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(DressServerApplication.class, args);
    }

}
