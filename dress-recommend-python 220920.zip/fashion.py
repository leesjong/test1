
# -*- coding: utf-8 -*-
import numpy as np
import cv2
import matplotlib.image as mpimg
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans
import os
import random
import sys
import warnings
warnings.filterwarnings('ignore')
#####***************************************#########
# 스프링 프로잭트 내에 clothes 경로 입력
global clothes_path
clothes_path = "C:/Users/kosmo/Desktop/final-project/dress_recommend_server-master 220923/dress_recommend_server-master/src/main/resources/static/clothes"
#####***************************************#########



def centroid_histogram(clt):
    numLabels = np.arange(0, len(np.unique(clt.labels_)) + 1)
    (hist, _) = np.histogram(clt.labels_, bins=numLabels)
    hist = hist.astype("float")
    hist /= hist.sum()
    return hist


def plot_colors(hist, centroids):
    bar = np.zeros((50, 300, 3), dtype="uint8")
    startX = 0
    dict = {}
    global x
    for (percent, color) in zip(hist, centroids):
        dict[percent] = color
        endX = startX + (percent * 300)
        cv2.rectangle(bar, (int(startX), 0), (int(endX), 50),
                      color.astype("uint8").tolist(), -1)
        startX = endX
    sort_dict = sorted(dict.keys(), reverse=True)
    for key, value in dict.items():
        if key == sort_dict[1]:
            x = value
    return bar


def search(dirname):
    global y
    y = []
    filenames = os.listdir(dirname)
    for filename in filenames:
        full_filename = os.path.join(dirname, filename)
        ext = os.path.splitext(full_filename)[-1]
        if ext == '.png':
            y.append(full_filename)

    return y  # 파일 주소 반환


def image_color_cluster(image_path, k=5):
    image = cv2.imread(image_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = image.reshape((image.shape[0] * image.shape[1], 3))
    clt = KMeans(n_clusters=k)
    clt.fit(image)
    hist = centroid_histogram(clt)
    bar = plot_colors(hist, clt.cluster_centers_)
    return x  # rgb 값 반환


def app(inputNum):
    nums = []
    nearNum = 0
    minNum = 255
    for n in nums:
        absNum = abs(n - inputNum)
        if absNum < minNum:
            minNum = absNum
            nearNum = n
    print(nearNum)

    return nearNum


def test1(a):
    sa = []
    # 주소 배열 선언 후 랜덤으로 불러오기

    s = ""  # 디렉터리 주소 저장

    for i in search(a):
        rgbar = []
        count = 0
        for j in image_color_cluster(i):
            rgbar.append(int(j))

        for k in rgbar:
            if (k < 130):
                count = count+1

        if (count == 3):
            sa.append(i)

    sa = set(sa)
    sa = list(sa)
    si = random.choice(sa)
    image_path = si
    # preview image
    image = mpimg.imread(image_path)
    plt.imshow(image)
    image_color_cluster(image_path)
    return image_path


# 밝은색
def test2(a):
    sa = []
    # 주소 배열 선언 후 랜덤으로 불러오기
    s = ""  # 디렉터리 주소 저장
    for i in search(a):
        for j in image_color_cluster(i):
            if (j > 150):
                sa.append(i)

    sa = set(sa)
    sa = list(sa)
    si = random.choice(sa)
    image_path = si
    # preview image
    image = mpimg.imread(image_path)
    # plt.imshow(image)
    image_color_cluster(image_path)
    return image_path


def result(a, b):

    list_item = a
    xi = None
    if (list_item == 1):
        xi = test2(
            clothes_path+"/woman/shortt/")

    elif (list_item == 2):
        xi = test1(
            clothes_path+"/woman/shortt/")

    elif (list_item == 3):
        xi = test2(
            clothes_path+"/woman/longt/")

    elif (list_item == 4):
        xi = test1(
            clothes_path+"/woman/longt/")

    list_item2 = b
    yi = None
    if (list_item2 == 5):
        yi = test2(
            clothes_path+"/woman/shortp/")

    elif (list_item2 == 6):
        yi = test1(
            clothes_path+"/woman/shortp/")

    elif (list_item2 == 7):
        yi = test2(
            clothes_path+"/woman/longp/")

    elif (list_item2 == 8):
        yi = test1(
            "/woman/longp/")

    elif (list_item2 == 9):
        yi = test2(
            clothes_path+"/woman/shorts/")

    elif (list_item2 == 10):
        yi = test1(
            clothes_path+"/woman/shorts/")

    elif (list_item2 == 11):
        yi = test2(
            clothes_path+"/woman/longs/")

    elif (list_item2 == 12):
        yi = test1(
            clothes_path+"/woman/longs/")

    return [xi.replace(clothes_path, ""), yi.replace(clothes_path, "")]


def resultx(a, b):
    list_item = a
    ki = None
    if (list_item == 1):
        ki = test2(
            clothes_path+"/man/shortt/")

    elif (list_item == 2):
        ki = test1(
            clothes_path+"/man/shortt/")

    elif (list_item == 3):
        ki = test2(
            clothes_path+"/man/longt/")

    elif (list_item == 4):
        ki = test1(
            clothes_path+"/man/longt/")

    list_item2 = b
    bi = None
    if (list_item2 == 5):
        bi = test2(
            clothes_path+"/man/shortp/")

    elif (list_item2 == 6):
        bi = test1(
            clothes_path+"/man/shortp/")

    elif (list_item2 == 7):
        bi = test2(
            clothes_path+"/man/longp/")

    elif (list_item2 == 8):
        bi = test1(
            clothes_path+"/man/longp/")

    return [ki.replace(clothes_path, ""), bi.replace(clothes_path, "")]


run_type = sys.argv[1]
# print(run_type)
if (run_type == '1'):
    print(result(int(sys.argv[2]), int(sys.argv[3])))
elif (run_type == '2'):
    print(resultx(int(sys.argv[2]), int(sys.argv[3])))
